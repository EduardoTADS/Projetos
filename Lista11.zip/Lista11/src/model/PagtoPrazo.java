package model;

public interface PagtoPrazo {
	public float getJuros();
	
}
