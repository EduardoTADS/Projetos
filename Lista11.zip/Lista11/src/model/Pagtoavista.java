package model;

public interface Pagtoavista {
	
	public float getDesconto();
}
