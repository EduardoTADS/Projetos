module Lista10 {
	requires java.desktop;
}